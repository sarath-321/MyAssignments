package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.LoginPage;
import projectSpecificMethod.base;

public class DeleteIndividual extends base {
	@BeforeTest
	public void setFile() {
		excelFileName="DeleteIncidentData";
		testcaseName="DeleteIndividual";
		testDescription="checking the functionality of salesforce"; testAuthor="keerthana";
		testCategory="Functional";
		
	}
	
	@Test(dataProvider="myData")
	public  void runDelete(String search) throws InterruptedException, IOException {
		LoginPage ob = new LoginPage(driver, test);
		ob.enterUsername()
		.enterPassword()
		.clickLogin()
		.clickAppLauncher()
		.clickViewAll()
		.clickIndividuals()
		.searchName(search)
		.selectIndividual()
		.clickDelete()
		.verifyDelete();
	}
}
