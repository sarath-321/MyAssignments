package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.LoginPage;
import projectSpecificMethod.base;

public class EditIndividual extends base {
	@BeforeTest
	public void setFile() {
		excelFileName="EditIncidentData";
		testcaseName="EditIndividual";
		testDescription="checking the functionality of salesforce"; testAuthor="keerthana";
		testCategory="Functional";
		
		
	}
	
	@Test(dataProvider="myData")
	public  void runEdit(String search, String fname) throws InterruptedException, IOException {
		LoginPage ob = new LoginPage(driver, test);
		ob.enterUsername()
		.enterPassword()
		.clickLogin()
		.clickAppLauncher()
		.clickViewAll()
		.clickIndividuals()
		.searchName(search)
		.selectIndividual()
		.clickEdit()
		.clickSalutation()
		.clearFirstName()
		.enterFirstName(fname)
		.clickEditSave()
		.verifyEdit();
		
}
}
