package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.ExtentTest;

import projectSpecificMethod.base;

public class HomePage extends base {

	public HomePage(RemoteWebDriver driver, ExtentTest test) {
		this.driver=driver;
		this.test=test;
	}
	
	public HomePage clickAppLauncher() throws IOException {
		try {
		driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
		reportStep("pass","AppLauncher is clicked successfully");
		}
	catch(Exception e) {
		reportStep("fail", "AppLauncher is not clicked successfully");
	}
		return this;
	}
	
	public HomePage clickViewAll() throws IOException {
		try {
		driver.findElement(By.xpath("//button[text()='View All']")).click();
		reportStep("pass","ViewAll is clicked successfully");
		}
	catch(Exception e) {
		reportStep("fail", "ViewAll is not clicked successfully");
	}
		return this;
	}
	
	public SalesPage clickIndividuals() throws IOException {
		try {
		WebElement scroll = driver.findElement(By.xpath("//p[text()='Party Consent']"));
		driver.executeScript("arguments[0].scrollIntoView();", scroll);
		WebElement individual = driver.findElement(By.xpath("//p[text()='Individuals']"));
		driver.executeScript("arguments[0].click();", individual);
		reportStep("pass","Individuals is clicked successfully");
		}
	catch(Exception e) {
		reportStep("fail", "Individuals is not clicked successfully");
	}
		return new SalesPage(driver,test);
	}

}
