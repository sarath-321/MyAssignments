package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.ExtentTest;

import projectSpecificMethod.base;

public class IndividualsPage extends base {

	public IndividualsPage(RemoteWebDriver driver, ExtentTest test) {
		this.driver=driver;
		this.test=test;
	}
	
	public IndividualsPage verifyIndividual() throws IOException {
		try {
		String message = driver.findElement(By.xpath("//span[@class='toastMessage slds-text-heading--small forceActionsText']")).getText();
		//verify Individuals Name
		String text = driver.findElement(By.xpath("//span[@class='uiOutputText']")).getText();
		if(text.equalsIgnoreCase("Muthukumar")) {
			System.out.println("name is verified");
		}
		else {
			System.out.println("name is not verified");
		}
		reportStep("pass","Individual created successfully");
		}
	catch(Exception e) {
		reportStep("fail", "Individual is not created successfully");
	}
		return this;
	}

}
