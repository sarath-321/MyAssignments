package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.ExtentTest;

import projectSpecificMethod.base;

public class LoginPage extends base {
	public LoginPage(RemoteWebDriver driver,ExtentTest test) {
		this.driver=driver;
		this.test=test;
	}
	
	public LoginPage enterUsername() throws IOException {
		try {
		driver.findElement(By.id("username")).sendKeys("sarathkumar.thangavel97@testleaf.com");
		reportStep("pass","userName is entered successfully");
		}
	catch(Exception e) {
		reportStep("fail", "userName is not entered successfully");
	}
		
		return this;
	}
	
	public LoginPage enterPassword() throws IOException {
		try {
		driver.findElement(By.id("password")).sendKeys("Leaf@1234");
		reportStep("pass","password is entered successfully");
		}
	catch(Exception e) {
		reportStep("fail", "password is not entered successfully");
	}
		
		return this;
	}
	
	public HomePage clickLogin() throws IOException {
		try {
		driver.findElement(By.id("Login")).click();
		reportStep("pass","Login is  successfull");
		}
	catch(Exception e) {
		reportStep("fail", "Login is not  successfull");
	}
		return new HomePage(driver,test);
	}
	
	


}
