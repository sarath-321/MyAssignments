package utils;

import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel {

	 public static String[][] readExcel(String filename) throws IOException {

	//public static void main(String[] args) throws IOException {

		XSSFWorkbook book = new XSSFWorkbook("./data/"+filename+".xlsx");
		XSSFSheet wsheet = book.getSheetAt(0);
		int rowcount = wsheet.getLastRowNum();// row count without header
		short columnCount = wsheet.getRow(0).getLastCellNum();
		String[][] data = new String[rowcount][columnCount];
		for (int i = 1; i <= rowcount; i++) {// row

			for (int j = 0; j < columnCount; j++) {// cell 0 1 2
				String stringCellValue = wsheet.getRow(i).getCell(j).getStringCellValue();
				data[i - 1][j] = stringCellValue;// 0,0
				System.out.println(stringCellValue);
			}

		}
		book.close();
		return data;

	}

}
