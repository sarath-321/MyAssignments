package ExceptionHandling;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LearnScreenshot {

	public static void main(String[] args) throws IOException {
	ChromeDriver	driver  = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://leaftaps.com/opentaps/control/main");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.findElement(By.id("username")).sendKeys("demoSalesManager");
		driver.findElement(By.id("password")).sendKeys("crmsfa");
		driver.findElement(By.className("decorativeSubmit")).click();
		driver.findElement(By.linkText("CRM/SFA")).click();
		
		//to take screenshot of complete web page 
		int random =(int)(Math.random()*999999);
		File screenshotAs = driver.getScreenshotAs(OutputType.FILE);
		File destn=new File("./Picture/snap"+random+".png");
		FileUtils.copyFile(screenshotAs, destn);
		//After the exe refresh your project to have the picture folder and open with system editor

		//to take the screenshot of particular webElement
		WebElement Lead = driver.findElement(By.linkText("Leads"));
		
		File screen = Lead.getScreenshotAs(OutputType.FILE);
		File ele=new File("./Picture/snap1.png");
		FileUtils.copyFile(screen, ele);
		
		
		
	}

}
