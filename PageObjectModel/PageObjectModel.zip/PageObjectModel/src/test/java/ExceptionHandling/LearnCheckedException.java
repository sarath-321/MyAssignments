package ExceptionHandling;

public class LearnCheckedException {
	
	
	public static void sub(int a,int b) {
		if(a>b) {
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				System.out.println(e);
			}
			System.out.println(a-b);			
		}else {
			throw new RuntimeException("Check the inputs");
		}
	}	

	public static void main(String[] args)  {
				
		sub(3,5);
		
	}

}
