package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;


public class CreateLead extends ProjectSpecificMethod {

	@BeforeTest
	public void setData() {
		filename="CreateLeadTestdata";
		testcaseName="CreateLead";
		testDesc="Lead with Mandatory fields";
		author="Pavitra";
		category="Regression";
	}
	
	
	@Test(dataProvider="fetchData")
	public void runCreate(String cname, String fname,String lname,String phno) throws IOException {
		
			
		LoginPage ob=new LoginPage(driver,node);
		ob.enterUsername()
		.enterPassword()
		.clickLogin()
		.clickCrmsfa()
		.clickLeads()
		.clickCreateLead()
		.enterCompanyname(cname)
		.enterFirstName(fname)
		.enterLastName(lname)
		.clickCreate()
		.verifyLeadName();
		
		
	}
	
}
