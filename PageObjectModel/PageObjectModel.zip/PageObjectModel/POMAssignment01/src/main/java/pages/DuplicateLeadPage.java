package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectSpecificMethod;

public class DuplicateLeadPage extends ProjectSpecificMethod{
	
	public DuplicateLeadPage(RemoteWebDriver driver) {
		this.driver=driver;
	}
	
	public DuplicateLeadPage clearCompName() {
		driver.findElement(By.id("createLeadForm_companyName")).clear();
		return this;
	}
	public DuplicateLeadPage enterDupCompName(String dupCompanyName) {
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(dupCompanyName);
		return this;
	}
	
	public DuplicateLeadPage clearfirstNameLocal() {
		driver.findElement(By.id("createLeadForm_firstNameLocal")).clear();
		
		return this;
	}
	public DuplicateLeadPage enterDupFirstNameLocal(String dupFirstNameLocal) {
		driver.findElement(By.id("createLeadForm_firstNameLocal")).sendKeys(dupFirstNameLocal);
		return this;
	}
	
	public ViewLeadPage clickSubmit() {
		driver.findElement(By.className("smallSubmit")).click();
		return new ViewLeadPage(driver);
	}
	

}
