package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectSpecificMethod;

public class EditLeadPage extends ProjectSpecificMethod{
	
	public EditLeadPage(RemoteWebDriver driver) {
		this.driver=driver;
	}
	
	public EditLeadPage editCompanyName(String compName) {
		WebElement companyName = driver.findElement(By.id("updateLeadForm_companyName"));
		companyName.clear();
		companyName.sendKeys(compName);
		return this;
	}
	
	public ViewLeadPage clickUpdate() {
		driver.findElement(By.name("submitButton")).click();
		return new ViewLeadPage(driver);
	}

}
