package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectSpecificMethod;

public class AlertPage extends ProjectSpecificMethod{
	
	public AlertPage(RemoteWebDriver driver) {
		this.driver=driver;
	}
	
	public ViewLeadPage acceptAlert() {
		driver.switchTo().alert().accept();
		return new ViewLeadPage(driver);
		
	}

}
