package pages;

import java.util.ArrayList;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectSpecificMethod;

public class MergeLeadPage extends ProjectSpecificMethod{

	
	public MergeLeadPage(RemoteWebDriver driver) {
		this.driver=driver;
	}
	
	public NewFindLeadsWindowPage clickLookupOne() {
		driver.findElement(By.xpath("//img[@alt='Lookup']")).click();
		return new NewFindLeadsWindowPage(driver);
	}
	
	public MergeLeadPage switchDriver1() {
		Set<String> allWindowss = driver.getWindowHandles();
		allhandles = new ArrayList<String>(allWindowss);
		driver.switchTo().window(allhandles.get(0));
		return this;
	}
	
	public NewFindLeadsWindowPage clickLookupTwo() {
		driver.findElement(By.xpath("(//img[@alt='Lookup'])[2]")).click();
		Set<String> allWindows = driver.getWindowHandles();
		allhandles = new ArrayList<String>(allWindows);
		return new NewFindLeadsWindowPage(driver);
		
	}
	
	public MergeLeadPage switchDriver2() {
		driver.switchTo().window(allhandles.get(0));
		return this;
	}
	
	public AlertPage clickMerge() {
		driver.findElement(By.xpath("//a[text()='Merge']")).click();
		return new AlertPage(driver);
	}
	
}
