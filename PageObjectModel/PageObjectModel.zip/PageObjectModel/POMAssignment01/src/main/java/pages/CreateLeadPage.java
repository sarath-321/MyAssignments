package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;

import base.ProjectSpecificMethod;

public class CreateLeadPage extends ProjectSpecificMethod{

	public CreateLeadPage(RemoteWebDriver driver) {
		this.driver=driver;
	}
	
	public CreateLeadPage enterCompanyname(String cname) {
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(cname);
		return this;
	}
	
	public CreateLeadPage enterFirstName(String fname) {
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(fname);
		return this;
	}
	
   public CreateLeadPage enterLastName(String lname) {
	   driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lname);
	   return this;
	}
   
   public CreateLeadPage enterprimaryPhoneNumber(String phnNo) {
	   driver.findElement(By.id("createLeadForm_primaryPhoneNumber")).sendKeys(phnNo);
	   return this;
	}
   
   public CreateLeadPage enterFirstNameLocal(String firstNameLocal) {
	   driver.findElement(By.id("createLeadForm_firstNameLocal")).sendKeys(firstNameLocal);
	   return this;
	}
   
   public CreateLeadPage enterDepartmentName(String departmentName) {
	   driver.findElement(By.id("createLeadForm_departmentName")).sendKeys(departmentName);
	   return this;
	}
   
   public CreateLeadPage enterDescription(String description) {
	   driver.findElement(By.id("createLeadForm_description")).sendKeys(description);
	   return this;
	}
   
   public CreateLeadPage enterEmail(String email) {
	   driver.findElement(By.id("createLeadForm_primaryEmail")).sendKeys(email);
	   return this;
	}
   public CreateLeadPage selectState() {
	   WebElement state = driver.findElement(By.id("createLeadForm_generalStateProvinceGeoId"));
		Select select= new Select(state);
		select.selectByVisibleText("Alaska");
	   return this;
	}
     
   public ViewLeadPage clickSubmit() {
	   driver.findElement(By.name("submitButton")).click();
	   return new ViewLeadPage(driver);
	}
	
	
	
}
