package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectSpecificMethod;


public class ViewLeadPage extends ProjectSpecificMethod{

	public ViewLeadPage(RemoteWebDriver driver) {
		this.driver=driver;
	}
	
	public ViewLeadPage checkViewLeadPage(String cname) {
		
		text = driver.findElement(By.id("viewLead_companyName_sp")).getText();
		   if (text.contains(cname)) {
				System.out.println("Lead created successfully");
			} else {
				System.out.println("Lead is not created");
			}
		   return this;
	}
	
	public EditLeadPage clickEdit() {
		driver.findElement(By.linkText("Edit")).click();
		return new EditLeadPage(driver);
	}
	
	public void verifyCompanyName(String compName) throws InterruptedException {
		String text = driver.findElement(By.id("viewLead_companyName_sp")).getText();
		if (text.contains(compName)) {
			System.out.println("Lead is editted successfully");
		}
		else {
			System.out.println("Lead is not editted");
		}
		Thread.sleep(3000);
	}
	
	
	public DuplicateLeadPage clickDuplicateLead() {
		driver.findElement(By.linkText("Duplicate Lead")).click();
		return new DuplicateLeadPage(driver);
	}
	
	
	public void verifyDupCompanyName(String dupCompanyName) throws InterruptedException {
		String text = driver.findElement(By.id("viewLead_companyName_sp")).getText();
		if (text.contains(dupCompanyName)) {
			System.out.println("Duplicate Lead is created successfully");
		}
		else {
			System.out.println("Duplicate Lead is not created");
		}
		Thread.sleep(3000);
	}
	
	public FindLeadsPage clickFindLeads() {
		driver.findElement(By.linkText("Find Leads")).click();
		return new FindLeadsPage(driver);
	}
	
	public MyLeadsPage clickDelete() {
		driver.findElement(By.linkText("Delete")).click();
		return new MyLeadsPage(driver);
	}
	
}
