package pages;

import java.util.ArrayList;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectSpecificMethod;

public class NewFindLeadsWindowPage extends ProjectSpecificMethod{

	public NewFindLeadsWindowPage(RemoteWebDriver driver) {
		this.driver=driver;
	}
	
	public NewFindLeadsWindowPage switchFirstWindow() {
		Set<String> allWindows = driver.getWindowHandles();
		allhandles = new ArrayList<String>(allWindows);
		driver.switchTo().window(allhandles.get(1));	
		return this;
	}
	
	public NewFindLeadsWindowPage enterFirstName(String firstName) {
		driver.findElement(By.xpath("//input[@name='firstName']")).sendKeys(firstName);
		return this;
	}
	
	public NewFindLeadsWindowPage clickFindLeads() throws InterruptedException {
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
		Thread.sleep(1000);
		return this;
	}
	
	public NewFindLeadsWindowPage getLeadId() {
		leadID = driver.findElement(By.xpath("(//a[@class='linktext'])[1]")).getText();
		System.out.println("Lead id :"+leadID);
		return this;
	}
	public MergeLeadPage clickFirstElement1() {
		driver.findElement(By.xpath("(//a[@class='linktext'])[1]")).click();
		return new MergeLeadPage(driver);
	}
	
	public NewFindLeadsWindowPage enterMergeFirstName(String mergeFirstName) {
		driver.findElement(By.xpath("//input[@name='firstName']")).sendKeys(mergeFirstName);
		return this;
	}
	public MergeLeadPage clickFirstElement2() {
		driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).click();
		return new MergeLeadPage(driver);
	}
	
}
