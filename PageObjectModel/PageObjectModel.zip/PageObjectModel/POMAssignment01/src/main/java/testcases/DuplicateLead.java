package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class DuplicateLead extends ProjectSpecificMethod{

	@BeforeTest
	public void setFile() {
		fileName="DuplicateLeadData";
	}
	
	@Test(dataProvider = "fetchData")
	public void EditLead(String cname
		       ,String fname,String lname,String phnNo,String firstNameLocal
	           ,String departmentName,String description,String email
	           ,String dupCompanyName,String dupFirstNameLocal) throws InterruptedException {
		
		LoginPage ob=new LoginPage(driver);
		ob.enterUsername()
		.enterPassword()
		.clickLogin()
		.clickCrmsfa()
		.clickLeads()
		.clickCreateLead()
		.enterCompanyname(cname)
		.enterFirstName(fname)
		.enterLastName(lname)
		.enterFirstNameLocal(dupFirstNameLocal)
		.enterDepartmentName(departmentName)
		.enterDescription(description)
		.enterEmail(email)
		.selectState()
		.clickSubmit()
		.checkViewLeadPage(cname)
		.clickDuplicateLead()
		.clearCompName()
		.enterDupCompName(dupCompanyName)
		.clearfirstNameLocal()
		.enterDupFirstNameLocal(dupFirstNameLocal)
		.clickSubmit()
		.verifyDupCompanyName(dupCompanyName);
		
	}
	
}
