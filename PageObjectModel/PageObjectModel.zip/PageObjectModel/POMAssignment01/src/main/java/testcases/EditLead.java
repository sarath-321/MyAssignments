package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class EditLead extends ProjectSpecificMethod{

	@BeforeTest
	public void setFile() {
		fileName="EditLeadData";
	}
	
	@Test(dataProvider = "fetchData")
	public void runEditLead(String phoneNumber,String compName) throws InterruptedException {
		
		LoginPage ob=new LoginPage(driver);
		ob.enterUsername()
		.enterPassword()
		.clickLogin()
		.clickCrmsfa()
		.clickLeads()
		.clickFindLeads()
		.clickPhone()
		.enterPhoneNumber(phoneNumber)
		.clickFindLeads()
		.clickFirstElement()
		.clickEdit()
		.editCompanyName(compName)
		.clickUpdate()
		.verifyCompanyName(compName);
		
		
		
	}
	
}

