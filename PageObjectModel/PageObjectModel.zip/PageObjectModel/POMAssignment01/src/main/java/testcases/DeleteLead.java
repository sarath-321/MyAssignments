package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class DeleteLead extends ProjectSpecificMethod{

	@BeforeTest
	public void setFile() {
		fileName="DeleteLeadData";
	}
	
	@Test(dataProvider = "fetchData")
	public void runEditLead(String phoneNumber) throws InterruptedException {
		
		LoginPage ob=new LoginPage(driver);
		ob.enterUsername()
		.enterPassword()
		.clickLogin()
		.clickCrmsfa()
		.clickLeads()
		.clickFindLeads()
		.clickPhone()
		.enterPhoneNumber(phoneNumber)
		.clickFindLeads()
		.clickFirstElement()
		.clickDelete()
		.clickFindLeads()
		.clickPhone()
		.enterPhoneNumber(phoneNumber)
		.clickFindLeads()
		.verifyDeleteLead()
		;
		
		
		
	}
}
