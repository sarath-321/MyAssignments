package ui;

import org.testng.annotations.Test;

public class DemoTest {

	@Test
	public void test1() {
		System.out.println("This is Test1");
	}
	
	@Test
	public void test2() {
		System.out.println("This is Test2");
	}
	
	
}
