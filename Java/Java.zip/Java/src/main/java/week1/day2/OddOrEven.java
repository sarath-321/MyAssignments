package week1.day2;

public class OddOrEven {

	public static void main(String[] args) {

		int num = 15;

		if (num % 2 == 0) {
			System.out.println("The given number " + num + " is Even");
		} else {
			System.out.println("The given number " + num + " is Odd");
		}

	}

}
