package week1.day2;

import org.openqa.selenium.chrome.ChromeDriver;

public class CheckingSeleniumDriver {

	public static void main(String[] args) {
		
		ChromeDriver driver=new ChromeDriver(); 
		driver.get("https://chromedriver.chromium.org/home");

	}

}
