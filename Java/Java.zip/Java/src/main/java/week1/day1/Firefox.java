package week1.day1;

public class Firefox {

	public static void main(String[] args) {

		float version = 100.2f;
		String name = "firefox";
		boolean visible = true;
		int year = 1998;
		char logo = 'm';

		System.out.println("Version :" + version);
		System.out.println("Name    :" + name);
		System.out.println("Visible :" + visible);
		System.out.println("Year    :" + year);
		System.out.println("Logo    :" + logo);

	}

}
