package week1.day1;

public class Mobile {

	public void sendSms() {
		System.out.println("From OPPO");
	}

	public void makeCall() {
		System.out.println("Calling my friend");
	}

	public static void main(String[] args) {

		Mobile mob = new Mobile();
		mob.sendSms();
		mob.makeCall();

	}

}
