package week4.day1.classroom;

import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;

public class LearnList {

	public static void main(String[] args) {
		
//		ChromeDriver driver=new ChromeDriver();
//        driver.get("https://www.amazon.in/");
//        driver.manage().window().maximize();
//        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		String str1="Hello";
		String str2="World";
		str1.concat(str2);
		System.out.println(str1);
        
        
        
        



	}

}
