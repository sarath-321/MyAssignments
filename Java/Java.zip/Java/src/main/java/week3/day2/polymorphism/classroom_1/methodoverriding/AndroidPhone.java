package week3.day2.polymorphism.classroom_1.methodoverriding;

public class AndroidPhone {

	public void takeVideo() {
		System.out.println("Taking video from Android Phone");
	}
}
