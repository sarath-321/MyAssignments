package week3.day2.array;

import java.util.Arrays;

public class ReverseanArray {

	public static void main(String[] args) {
		
int[] nums = {22, 3981, -19, 82, 0, 45, 37};
		
		Arrays.sort(nums);
		System.out.print("[");
		
		for(int i=nums.length-1;i>=0;i--) {
			System.out.print(nums[i]+",");
		}
		
		System.out.print("]");

	}

}
