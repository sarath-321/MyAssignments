package week3.day2.string.classroom;
public class ReverseTheString {

	public static void main(String[] args) {
		
		String  input="LearningString";
		char[] ch= input.toCharArray();
		for (int i = ch.length-1; i>=0 ; i--) {
			System.out.print(ch[i]);
		}

	}

}
