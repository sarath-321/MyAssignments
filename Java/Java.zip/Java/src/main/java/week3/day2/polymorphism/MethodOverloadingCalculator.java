package week3.day2.polymorphism;

public class MethodOverloadingCalculator {
	
	public void add(int x,int y) {
		System.out.println(x+y);
	}
	public void add(int x,int y,int z) {
		System.out.println(x+y+z);
	}
	public void add(float x,float y) {
		System.out.println(x+y);
	}

	public static void main(String[] args) {
		
		MethodOverloadingCalculator cl= new MethodOverloadingCalculator();
		cl.add(10, 12);
		cl.add(14, 1, 60);
		cl.add(5.5f, 2.5f);
		

	}

}
