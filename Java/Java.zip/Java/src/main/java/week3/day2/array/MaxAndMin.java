package week3.day2.array;

import java.util.Arrays;

public class MaxAndMin {

	public static void main(String[] args) {
		
		int[] sensex= {23234,2343,56765,21435};
		int x=10;
		Arrays.sort(sensex);
		System.out.println(Arrays.toString(sensex));
		System.out.println(x);
		System.out.println(sensex[1]);
		System.out.println(sensex[sensex.length-2]);

	}

}
