package week3.day2.polymorphism.classroom_1.methodoverriding;

public class SmartPhone extends AndroidPhone{

	public void takeVideo() {
		System.out.println("Taking video from Smart Phone");
	}
	
	public static void main(String[] args) {
		
		SmartPhone sp= new SmartPhone();
		sp.takeVideo();

	}

}
