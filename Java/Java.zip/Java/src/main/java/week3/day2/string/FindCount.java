package week3.day2.string;

public class FindCount {

	public static void main(String[] args) {
		
		String s="Testleaf Learning";
		//count the occurence of e
		
		//Method 1
		int count=0;
		for(int i=0;i<=s.length()-1;i++) {
			if(s.charAt(i)=='t') {
				//charAt()=e -->e==e
				count++;//+1+1
			}
		}
		
		System.out.println("The occurence of t in the String "+s +" "+count);
		
		//Method:2
				int counter=0;
				char[] charArray = s.toCharArray();
				
				for(int i=0;i<=charArray.length-1;i++) {
					if(charArray[i]=='e') {
						counter++;
					}
				}
				
				System.out.println("The occurence of e in the String "+s +" "+counter);

	}

}
