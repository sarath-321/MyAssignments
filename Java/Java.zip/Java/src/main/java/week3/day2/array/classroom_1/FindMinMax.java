package week3.day2.array.classroom_1;

import java.util.Arrays;

public class FindMinMax {

	public static void main(String[] args) {
		
		int[] nums= {22,3981,-19,82,0,45,37};
		Arrays.sort(nums);
		System.out.println("Second min value :"+nums[1]);
		System.out.println("Second max value :"+nums[nums.length-2]);

	}

}
