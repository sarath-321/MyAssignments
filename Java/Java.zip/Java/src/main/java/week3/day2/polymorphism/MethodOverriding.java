package week3.day2.polymorphism;


class MyClass{
	
	public void house() {
		System.out.println("My Father's house");
	}
	public void loan(long lakhs) {
		System.out.println("Loan :"+ lakhs);
	}
}


public class MethodOverriding extends MyClass{
	
	public void house() {
		super.house();
		System.out.println("I Built my own house");
	}
	public void loan(long lakhs) {
		System.out.println("Loan :"+ lakhs);
	}
	
	

	public static void main(String[] args) {
		
		MethodOverriding mo= new MethodOverriding();
		mo.house();
		mo.loan(4500000L);

	}

}
