package week3.day2.polymorphism;

public class MethodOverloading {
	
	public void empDetails(String name, int empId) {
		System.out.println(name+" "+empId);
	}
	public void empDetails(long phno, String desgn) {
		System.out.println(phno+" "+desgn);
	}
	public void empDetails() {
		System.out.println("Learning Overloading");
	}

	public static void main(String[] args) {
		
		MethodOverloading mo= new MethodOverloading();
		mo.empDetails("Juju", 123);
		mo.empDetails(9876543210L, "Tester");
		mo.empDetails();
		

	}

}
