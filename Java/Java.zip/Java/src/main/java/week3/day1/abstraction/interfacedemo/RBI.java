package week3.day1.abstraction.interfacedemo;

public interface RBI {

	public void withDrawal();
	public void kycDoc();
	
}
