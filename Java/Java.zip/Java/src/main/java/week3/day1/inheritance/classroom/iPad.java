package week3.day1.inheritance.classroom;

public class iPad extends iOS{
	
	public void watchMovie() {
		System.out.println("Watching movie...");
	}

}
