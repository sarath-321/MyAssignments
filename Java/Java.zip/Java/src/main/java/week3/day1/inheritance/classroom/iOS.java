package week3.day1.inheritance.classroom;

public class iOS {
	
	public void startApp() {
	    System.out.println("Starting App...");
	}
	public void increaseVolume() {
		System.out.println("Increasing volume...");
	}
	public void shutDown() {
		System.out.println("Shutting down...");
	}

	
}
