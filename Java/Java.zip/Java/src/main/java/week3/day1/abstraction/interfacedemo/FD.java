package week3.day1.abstraction.interfacedemo;

public interface FD extends RBI {

	public void fdLimit();
}
