package week3.day1.abstraction.classroom;

public interface Android {

	public void openApp();
	public void playVideo();
}
