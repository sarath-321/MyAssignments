package week3.day1.abstraction.interfacedemo;

public interface Loan {
	
	public void securityDoc();

}
