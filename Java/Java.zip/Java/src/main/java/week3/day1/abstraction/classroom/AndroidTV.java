package week3.day1.abstraction.classroom;

public abstract class AndroidTV implements Android {
	
	public void openApp() {
		System.out.println("Opening Android App...");
	}

}
