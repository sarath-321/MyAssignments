package week3.day1.abstraction.interfacedemo;

public class SBI implements RBI,Loan,GoldLoan{

	public void withDrawal() {
		System.out.println("Withdrawal amount more than 15L, needs PAN");
		
	}

	public void kycDoc() {
		System.out.println("KYC Document : Aadhar");
		
	}
	
	public void securityDoc() {
		System.out.println("Security Document : EC");
		
	}
	
	public void returnOfInterest() {
		System.out.println("ROI : 0.5%");
		
	}
	
	public void motorLoan() {
		System.out.println("Loan for vehicle");
	}
	
	public static void main(String[] args) {
		
		SBI sbi= new SBI();
		sbi.withDrawal();
		sbi.kycDoc();
		sbi.securityDoc();
		sbi.returnOfInterest();
		sbi.motorLoan();
	}
}
