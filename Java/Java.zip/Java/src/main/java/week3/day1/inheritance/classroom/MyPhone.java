package week3.day1.inheritance.classroom;

public class MyPhone {

	public static void main(String[] args) {
		
		iPhone ipn= new iPhone();
		ipn.startApp();
		ipn.increaseVolume();
		ipn.shutDown();
		ipn.makeCall();
		ipn.sendSms();

	}
}
