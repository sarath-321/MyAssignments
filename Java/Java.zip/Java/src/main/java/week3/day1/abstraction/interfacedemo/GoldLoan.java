package week3.day1.abstraction.interfacedemo;

public interface GoldLoan {
	
	public void returnOfInterest();

}
