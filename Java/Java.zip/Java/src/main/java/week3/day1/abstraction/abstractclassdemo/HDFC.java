package week3.day1.abstraction.abstractclassdemo;

public class HDFC extends LoanDetails{

	@Override
	public void surity() {
		System.out.println("Surity : 100%");
		
	}
	

}
