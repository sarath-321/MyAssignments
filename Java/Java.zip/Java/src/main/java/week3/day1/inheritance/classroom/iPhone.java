package week3.day1.inheritance.classroom;

public class iPhone extends iOS{
	
	public void makeCall() {
		System.out.println("Making Call...");
	}
	public void sendSms() {
		System.out.println("Sending SMS...");
	}

}
