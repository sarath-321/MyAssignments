package week3.day1.inheritance;

public class Auto extends Vehicle{

	public void wheelCount() {
		System.out.println("3 wheels");
	}
	
	
}