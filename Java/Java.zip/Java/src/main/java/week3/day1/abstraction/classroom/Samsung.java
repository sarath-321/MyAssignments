package week3.day1.abstraction.classroom;

public class Samsung implements Android{

	public void openApp() {
		System.out.println("Opening samsung app...");
		
	}

	public void playVideo() {
		System.out.println("Playing video...");
		
	}
	
	public static void main(String[] args) {
		
		Samsung sam= new Samsung();
		sam.openApp();
		sam.playVideo();
	}

}
