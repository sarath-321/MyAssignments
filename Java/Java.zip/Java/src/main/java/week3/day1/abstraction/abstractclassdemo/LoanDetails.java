package week3.day1.abstraction.abstractclassdemo;

public abstract class LoanDetails {
	
	public abstract void surity();
	public void paySlip() {
		System.out.println("3 Months");
	}

}
