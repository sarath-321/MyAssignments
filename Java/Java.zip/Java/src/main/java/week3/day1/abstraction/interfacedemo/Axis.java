package week3.day1.abstraction.interfacedemo;

public class Axis implements RBI{

	public void withDrawal() {
		System.out.println("Withdrawal amount more than 10L, needs PAN");
		
	}

	public void kycDoc() {
		System.out.println("KYC Document : PaySlip");
		
	}
	
	public void fdLimit() {
		System.out.println("FD Limit : 5L");
	}

}
