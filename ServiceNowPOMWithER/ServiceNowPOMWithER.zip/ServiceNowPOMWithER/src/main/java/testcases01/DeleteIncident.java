package testcases01;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class DeleteIncident extends ProjectSpecificMethod{
	
	@BeforeTest
	public void setData() {
		fileName="DeleteIncidentData";
		testcaseName="DeleteIncidentData";
		testDesc="Deleting Incident Data";
		author="Sarath";
		category="Regression";
	}
	
	
	@Test(dataProvider = "fetchData")
	public void runCreateNewIncident(String incNumber) throws IOException {
			
		LoginPage ob=new LoginPage(driver,node);
		ob.enterUsername()
		.enterPassword()
		.clickLogin()
		.clickAll()
		.enterTextInFilter()
		.clickHighlightedItem()
		.enterIncidentNumber(incNumber)
		.clickIncident()
		.clickDelete()
		.clickOk()
		.enterIncidentNumber(incNumber)
		.verifyDeletedIncident(incNumber)
		;
		
		
	}

}
