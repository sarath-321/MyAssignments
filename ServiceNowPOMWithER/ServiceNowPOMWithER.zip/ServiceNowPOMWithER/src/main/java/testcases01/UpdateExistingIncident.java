package testcases01;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class UpdateExistingIncident extends ProjectSpecificMethod{

	
	@BeforeTest
	public void setData() {
		fileName="UpdateExistingIncidentData";
		testcaseName="UpdateExistingIncident";
		testDesc="UpdateExistingIncident";
		author="Sarath";
		category="Regression";
	}
	
	
	@Test(dataProvider = "fetchData")
	public void runCreateNewIncident(String incNumber) throws IOException {
			
		LoginPage ob=new LoginPage(driver,node);
		ob.enterUsername()
		.enterPassword()
		.clickLogin()
		.clickAll()
		.enterTextInFilter()
		.clickHighlightedItem()
		.enterIncidentNumber(incNumber)
		.clickIncident()
		.selectUrgency()
		.selectState()
		.clickUpdate()
		.verifyUpdatedIncident()
		;
		
		
	}
}
