package testcases01;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class CreateNewIncident extends ProjectSpecificMethod{
	
	@BeforeTest
	public void setData() {
		fileName="CreateNewIncidentData";
		testcaseName="CreateNewIncident";
		testDesc="Creating NewIncident";
		author="Sarath";
		category="Regression";
	}
	
	
	@Test(dataProvider = "fetchData")
	public void runCreateNewIncident(String description) throws IOException {
			
		LoginPage ob=new LoginPage(driver,node);
		ob.enterUsername()
		.enterPassword()
		.clickLogin()
		.clickAll()
		.enterTextInFilter()
		.clickHighlightedItem()
		.clickNew()
		.enterDesc(description)
		.clickSubmit()
		.searchIncidentNumber()
		.verifyIncident();
		;
		
		
	}

}
