package pages;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.ExtentTest;

import base.ProjectSpecificMethod;
import io.github.sukgu.Shadow;

public class IncidentPage extends ProjectSpecificMethod{
	
	public IncidentPage(RemoteWebDriver driver, ExtentTest node) {
		this.driver = driver;
		this.node = node;
	}
	
	public IncidentPage selectUrgency() throws IOException {
		try {
			Shadow selectUrg= new Shadow(driver);
			selectUrg.setImplicitWait(30);
			WebElement select = selectUrg.findElementByXPath("//select[contains(@name,'urgency')]");
			Select sl= new Select(select);
			sl.selectByValue("1");
			reportStatus("pass", "Urgency selected successfully");
		}
		catch(Exception e) {
			reportStatus("fail", "Urgency not selected");
		}
		return this;
	}
	
	public IncidentPage selectState() throws IOException {
		try {
			Shadow selectSt= new Shadow(driver);
			selectSt.setImplicitWait(30);
			WebElement select1 = selectSt.findElementByXPath("//select[contains(@name,'state')]");
			Select sl1= new Select(select1);
			sl1.selectByValue("2");
			reportStatus("pass", "State selected successfully");
		}
		catch(Exception e) {
			reportStatus("fail", "State not selected");
		}
		return this;
	}
	
	
	public IncidentViewPage clickUpdate() throws IOException {
		try {
			Shadow clickUp= new Shadow(driver);
			clickUp.setImplicitWait(30);
			clickUp.findElementByXPath("//button[@id='sysverb_update_bottom']").click();
			reportStatus("pass", "Update clicked successfully");
		}
		catch(Exception e) {
			reportStatus("fail", "Update not clicked");
		}
		return new IncidentViewPage(driver,node);
	}
	
	
	public IncidentPage clickDelete() throws IOException {
		try {
			Shadow clickDel= new Shadow(driver);
			clickDel.setImplicitWait(30);
			clickDel.findElementByXPath("//button[@id='sysverb_delete']").click();
			reportStatus("pass", "Delete clicked successfully");
		}
		catch(Exception e) {
			reportStatus("fail", "Delete not clicked");
		}
		return this;
	}
	
	public IncidentViewPage clickOk() throws IOException {
		try {
			Shadow clickOK= new Shadow(driver);
			clickOK.setImplicitWait(30);
			clickOK.findElementByXPath("//button[@id='ok_button']").click();
			reportStatus("pass", "Ok clicked successfully");
			
		}
		catch(Exception e) {
			reportStatus("fail", "ok not clicked");
		}
		return new IncidentViewPage(driver,node);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
