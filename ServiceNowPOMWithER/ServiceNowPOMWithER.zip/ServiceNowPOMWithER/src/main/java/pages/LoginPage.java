package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.ExtentTest;

import base.ProjectSpecificMethod;
import io.github.sukgu.Shadow;

public class LoginPage extends ProjectSpecificMethod{

	public LoginPage(RemoteWebDriver driver,ExtentTest node) {
		this.driver = driver;
		this.node = node;

	}
	
	public LoginPage enterUsername() throws IOException {
		try {
			driver.findElement(By.name("user_name")).sendKeys("admin");
			reportStatus("pass", "Username is entered successfully");
		} catch (Exception e) {
			reportStatus("fail", "Username is not entered");
		}

		return this;
	}
	
	public LoginPage enterPassword() throws IOException {
		try {
			driver.findElement(By.name("user_password")).sendKeys("Te8+iis2C+TT");
			reportStatus("pass", "Password is entered successfully");
		} catch (Exception e) {
			reportStatus("fail", "Password is not entered");
		}
		return this;
	}
	
	public WelcomePage clickLogin() throws IOException {
		try {
			driver.findElement(By.id("sysverb_login")).click();
			Thread.sleep(3000);
			sh = new Shadow(driver);
			reportStatus("pass", "Login button is clicked successfully");
		} catch (Exception e) {
			reportStatus("fail", "Login button is not clicked");
		}
		return new WelcomePage(driver, node);

	}
	
	
}
