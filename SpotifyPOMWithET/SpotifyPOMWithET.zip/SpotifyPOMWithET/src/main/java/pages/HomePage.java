package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectSpecificMethod;

public class HomePage extends ProjectSpecificMethod{

	public HomePage(RemoteWebDriver driver) {
		this.driver=driver;
	}
	
	public LoginPage clickLogin() throws IOException {
		try {
		driver.findElement(By.xpath("//span[text()='Log in']")).click();
		reportStatus("pass", "Login clicked successfully");
		}
		catch(Exception e) {
			reportStatus("fail", "Login not clicked");
		}
		return new LoginPage(driver);
	}
}
