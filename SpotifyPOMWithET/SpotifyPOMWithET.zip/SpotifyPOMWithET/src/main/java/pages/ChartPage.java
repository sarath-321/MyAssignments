package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectSpecificMethod;

public class ChartPage extends ProjectSpecificMethod{
	
	public ChartPage(RemoteWebDriver driver) {
		this.driver=driver;
	}
	
	public SearchPage clickSearch() throws IOException {
		try {
		driver.findElement(By.xpath("//span[text()='Search']")).click();;
		reportStatus("pass", "Search clicked successfully");
		}
		
		catch(Exception e) {
			reportStatus("fail", "Search not  clicked");
		}
		
		return new SearchPage(driver);
	}
}
