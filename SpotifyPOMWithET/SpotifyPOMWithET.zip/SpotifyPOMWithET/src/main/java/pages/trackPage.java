package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectSpecificMethod;

public class trackPage extends ProjectSpecificMethod{
	
	public trackPage(RemoteWebDriver driver) {
		this.driver=driver;
	}
	
	public trackPage clickPlayButton() throws IOException {
		try {
			driver.findElement(By.xpath("(//button[@aria-label='Play'])[3]")).click();
			Thread.sleep(2000);
			reportStatus("pass", "Play button clicked successfully");
		}
		catch(Exception e) {
			reportStatus("fail", "Play button not clicked");
		}
		return this;
	}

}
