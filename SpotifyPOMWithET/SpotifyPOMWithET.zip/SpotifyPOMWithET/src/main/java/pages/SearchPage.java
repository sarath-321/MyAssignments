package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectSpecificMethod;

public class SearchPage extends ProjectSpecificMethod{
	
	public SearchPage(RemoteWebDriver driver) {
		this.driver=driver;
	}
	
	public SearchPage search(String search) throws IOException {
		try {
			driver.findElement(By.xpath("//input[@placeholder='What do you want to listen to?']")).sendKeys(search,Keys.ENTER);
			reportStatus("pass", "Text entered in search box");
		}
		catch(Exception e) {
			reportStatus("fail", "Text entered in search box");
		}
		return this;
	}
	
	
	public trackPage clickHighlighted() throws IOException {
		try {
			driver.findElement(By.xpath("//div[contains(text(),'Paradise')]")).click();
			reportStatus("pass", "Highlighted element clicked successfully");
		}
		catch(Exception e) {
			reportStatus("fail", "Highlighted element not clicked");
		}
		return new trackPage(driver);
	}
	
	
	
}
