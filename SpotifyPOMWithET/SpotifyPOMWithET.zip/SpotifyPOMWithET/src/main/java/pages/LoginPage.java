package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectSpecificMethod;

public class LoginPage extends ProjectSpecificMethod{

	public LoginPage(RemoteWebDriver driver) {
		this.driver=driver;
	}
	
	public LoginPage enterUserName(String userName) throws IOException {
		try {
		driver.findElement(By.id("login-username")).sendKeys(userName);
		reportStatus("pass", "User name entered successfully");
		}
		
		catch(Exception e) {
			reportStatus("fail", "User name not entered");
		}
		return this;
	}
	
	
	public LoginPage enterPassword(String password) throws IOException {
		try {
			driver.findElement(By.id("login-password")).sendKeys(password);
			reportStatus("pass", "Password entered successfully");
		}
		catch(Exception e) {
			reportStatus("fail", "Password not entered");
		}
		return this;
	}
	
	public ChartPage clickLogin2() throws IOException {
		try {
			driver.findElement(By.xpath("//span[text()='Log In']")).click();
			reportStatus("pass", "Login clicked successfully");
			}
			catch(Exception e) {
				reportStatus("fail", "Login not clicked");
			}
			return new ChartPage(driver);
	}
	
	
}
