package base;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import utils.ReadExcel;


public class ProjectSpecificMethod {
	
	public RemoteWebDriver driver;
	public String fileName;
	public static ExtentReports extent;
	public static ExtentTest test,node;
	public String testCaseName,testDesc,author,category;
	
	
	@Parameters({"browser"})
	@BeforeMethod
	public void preCondition(String browser) {
		node = test.createNode(testCaseName);
		
		if(browser.equalsIgnoreCase("chrome")) {
			driver= new ChromeDriver();
		}
		else if(browser.equalsIgnoreCase("edge")) {
			driver= new EdgeDriver();
		}
		System.out.println(driver);
		driver.manage().window().maximize();
		driver.get("https://open.spotify.com/?");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
	}
	
//	@AfterMethod
//	public void postCondition() {
//		driver.close();
//	}
	
	@DataProvider(name="fetchData")
	public String[][] sendData() throws IOException{
		return ReadExcel.readData(fileName);
		
	}
	
	
	@BeforeSuite
	public void startReport() {
		ExtentHtmlReporter reporter= new ExtentHtmlReporter("./reports/result.html");
		extent= new ExtentReports();
		reporter.setAppendExisting(true);
		extent.attachReporter(reporter);
	}
	
	@AfterSuite
	public void endReport() {
		extent.flush();
	}
	
	@BeforeClass
	public void testDetails() {
		
		test=extent.createTest(testCaseName,testDesc);
		test.assignCategory(category);
		test.assignAuthor(author);
		
	}

	public int takeSnap() throws IOException {
		int random=(int)(Math.random()*999999);
		File source = driver.getScreenshotAs(OutputType.FILE);
		File dest= new File("./snap/shot"+random+".png");
		FileUtils.copyFile(source, dest);
		return random;
	}
	
	public void reportStatus(String status,String info) throws IOException {
		
		if(status.equalsIgnoreCase("pass")) {
			node.pass(info, MediaEntityBuilder.createScreenCaptureFromPath(".././snap/shot"+takeSnap()+".png").build());
		}
		else if(status.equalsIgnoreCase("fail")) {
			node.fail(info, MediaEntityBuilder.createScreenCaptureFromPath(".././snap/shot"+takeSnap()+".png").build());
			throw new RuntimeException("Check the testStep");
		}
	}
	
	
}
