package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.HomePage;

public class Login extends ProjectSpecificMethod{

	@BeforeTest
	public void setData() {
		fileName="PlaySongData";
		testCaseName="PlaySong";
		testDesc="PlaySong";
		author="Sarath";
		category="Functional";
		
	}
	
	@Test(dataProvider = "fetchData")
	public void runLogin(String username,String password,String searchText) throws IOException {
		HomePage obj= new HomePage(driver);
		obj.clickLogin()
		.enterUserName(username)
		.enterPassword(password)
		.clickLogin2()
		.clickSearch()
		.search(searchText)
		.clickHighlighted()
		.clickPlayButton()
		;
	}
	
}
