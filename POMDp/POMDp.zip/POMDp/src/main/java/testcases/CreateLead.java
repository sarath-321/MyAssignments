package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;


public class CreateLead extends ProjectSpecificMethod {

	@BeforeTest
	public void setFile() {
		fileName="CreateLeadData";
	}
	
	@Test(dataProvider = "fetchData")
	public void runCreate(String cname,String fname,String lname,String phnNo) {
		
		LoginPage ob=new LoginPage(driver);
		ob.enterUsername()
		.enterPassword()
		.clickLogin()
		.clickCrmsfa()
		.clickLeads()
		.clickCreateLead()
		.enterCompanyname(cname)
		.enterFirstName(fname)
		.enterLastName(lname)
		.enterprimaryPhoneNumber(phnNo)
		.clickSubmit()
		.checkViewLeadPage(cname);
		
		
	}
	
}
