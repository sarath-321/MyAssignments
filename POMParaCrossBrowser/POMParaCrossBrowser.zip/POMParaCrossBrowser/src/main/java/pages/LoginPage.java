package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectSpecificMethod;

public class LoginPage extends ProjectSpecificMethod {

	
	public LoginPage(RemoteWebDriver driver) {
		this.driver=driver;
	}
	
	
	//create methods for each webelement 
	//meaningful name along with action -->action+webelement
	public LoginPage enterUsername() {		
		driver.findElement(By.id("username")).sendKeys("demoSalesManager");
	//	LoginPage ob=new LoginPage();
		return new LoginPage(driver);
	}	
	
	public LoginPage enterPassword() {
		driver.findElement(By.id("password")).sendKeys("crmsfa");
		return new LoginPage(driver);
	}
	
	
	public WelcomePage clickLogin() {
		driver.findElement(By.className("decorativeSubmit")).click();
		return new WelcomePage(driver);
		
	}
	
	
	//chain of action
	//do method chaining
}
