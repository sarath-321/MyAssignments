package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectSpecificMethod;

public class FindLeadsPage extends ProjectSpecificMethod{

	public FindLeadsPage(RemoteWebDriver driver) {
		this.driver=driver;
	}
	
	public void searchLead() {
		
	}
	
	public ViewLeadPage clickFirstResulting() {
		//click first lead id
		return new ViewLeadPage(driver);
	}
}
