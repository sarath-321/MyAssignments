package listeners;

import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

//@Listeners(listeners.TestNGListeners.class)
public class ListenerRunner {

	@Test
	public void test01() {
		System.out.println("I am inside Test 01");
		
	}
	
	@Test
	public void test02() {
		System.out.println("I am inside Test 02");
		Assert.assertTrue(false);
	}
	
	@Test
	public void test03() {
		System.out.println("I am inside Test 03");
		throw new SkipException("Test skipped!");
	}
}
