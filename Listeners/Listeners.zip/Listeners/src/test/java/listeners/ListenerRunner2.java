package listeners;

import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

//@Listeners(listeners.TestNGListeners.class)
public class ListenerRunner2 {

	@Test
	public void test04() {
		System.out.println("I am inside Test 04");
		
	}
	
	@Test
	public void test05() {
		System.out.println("I am inside Test 05");
		Assert.assertTrue(false);
	}
	
	@Test
	public void test06() {
		System.out.println("I am inside Test 06");
		throw new SkipException("Test skipped!");
	}
}
