package wee7.day1.classroom;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class LearnWebTable {

	public static void main(String[] args) throws InterruptedException {
		

		ChromeDriver driver= new ChromeDriver();
		driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.get("https://erail.in/trains-between-stations/mgr-chennai-ctr-MAS/madurai-jn-MDU");
		
		WebElement from = driver.findElement(By.id("txtStationFrom"));
		from.clear();
		from.sendKeys("MAS");
		WebElement to = driver.findElement(By.id("txtStationTo"));
		to.clear();
		to.sendKeys("MDU");		
		driver.findElement(By.id("chkSelectDateOnly")).click();
		driver.findElement(By.id("buttonFromTo")).click();		
		Thread.sleep(3000);
		
		
		driver.findElement(By.xpath("//table[@class='DataTable TrainList TrainListHeader stickyTrainListHeader']"));
		List<WebElement> rows = driver.findElements(By.xpath("//table[@class='DataTable TrainList TrainListHeader stickyTrainListHeader']/tbody/tr"));
		int rsize = rows.size();
		//System.out.println("No.Of Rows " +rows.size());
		WebElement text1 = driver.findElement(By.xpath("//td[contains(text(),'Below trains not departing on')]"));
		String chk = text1.getText();
		for(int i=2;i<=rsize;i++) {
			
		    WebElement find = driver.findElement(By.xpath("//table[@class='DataTable TrainList TrainListHeader stickyTrainListHeader']/tbody/tr["+i+"]"));
		    String found = find.getText();
		    if(!(found.contains(chk))) {
		    	String col2Value = driver.findElement(By.xpath("//table[@class='DataTable TrainList TrainListHeader stickyTrainListHeader']/tbody/tr["+i+"]/td[2]")).getText();
			    System.out.println(col2Value);
		    	
		    }
		    else {
		    	break;
		    }
		}
	}

}
