package week2.practice;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class XpathPractice {

	public static void main(String[] args) {
		
		ChromeDriver cd= new ChromeDriver();
		cd.get("http://leaftaps.com/opentaps/control/main");
		cd.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		cd.manage().window().maximize();
		
		WebElement uname = cd.findElement(By.id("username"));
		uname.sendKeys("demoSalesManager");
		//to fetch typed value
		System.out.println(uname.getAttribute("value"));
		//to fetch attribute value
		System.out.println(uname.getAttribute("id"));	
	}
}
