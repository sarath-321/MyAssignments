package week2.day1;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class ElementVerification {

	public static void main(String[] args) {
		
		ChromeDriver cd= new ChromeDriver();
		cd.get("http://leaftaps.com/opentaps/control/main");
		cd.manage().window().maximize();
		
		//getAttribute- to get value of attribute
		System.out.println("getAttribute :"+cd.findElement(By.name("USERNAME")).getAttribute("class"));
		
		//getCssValue- to get taxt color (css elements)
		System.out.println("getCssValue :"+cd.findElement(By.className("decorativeSubmit")).getCssValue("background-color"));
		//get location
		System.out.println("getLocation :"+cd.findElement(By.className("decorativeSubmit")).getLocation().getX()); //or getLocation() include x,y
		//get size
		System.out.println("getSize :"+cd.findElement(By.className("decorativeSubmit")).getSize());// or getHeight()/getWidth()
		//get tag name
		System.out.println("getTagName :"+cd.findElement(By.className("decorativeSubmit")).getTagName());
		//isDisplayed-check element displayed or not
		System.out.println("isDisplayed :"+cd.findElement(By.className("decorativeSubmit")).isDisplayed());
		//isEnabled-check is the element currently enabled or not (text field editable/not editable
		System.out.println("isEnabled :"+cd.findElement(By.className("decorativeSubmit")).isEnabled());
		System.out.println("isEnabled :"+cd.findElement(By.xpath("//*[@id=\"login\"]/p[3]/input")).isEnabled());
		//isSelected- element selected or not/checkbox,buttons,dropdown,options
		System.out.println("isSelected :"+cd.findElement(By.xpath("//*[@id=\"login\"]/p[3]/input")).isSelected());
		
		cd.findElement(By.id("username")).sendKeys("demoSalesManager");
		cd.findElement(By.id("password")).sendKeys("crmsfa");
		cd.findElement(By.className("decorativeSubmit")).click();
		cd.findElement(By.linkText("CRM/SFA")).click();
		
		//getText- to get visible text
		System.out.println("getText :"+cd.findElement(By.id("sectionHeaderTitle_myHome")).getText());
	}

}
