package week2.day1;

import org.openqa.selenium.By;
import org.openqa.selenium.edge.EdgeDriver;

public class LaunchBrowser {

	public static void main(String[] args) {
		
//		ChromeDriver ch= new ChromeDriver();
//		ch.get("https://www.facebook.com/login");
		
		EdgeDriver ed= new EdgeDriver();
		ed.get("http://leaftaps.com/opentaps/control/main");
		
		ed.findElement(By.id("username")).sendKeys("demoSalesManager");
		ed.findElement(By.id("password")).sendKeys("crmsfa");
		ed.findElement(By.className("decorativeSubmit")).click();
		ed.findElement(By.linkText("CRM/SFA")).click();
		ed.findElement(By.linkText("Leads")).click();
		String str=ed.getTitle();
		System.out.println(str);
					
	}

}
