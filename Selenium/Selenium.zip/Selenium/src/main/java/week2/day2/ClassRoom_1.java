package week2.day2;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.edge.EdgeDriver;

public class ClassRoom_1 {

	public static void main(String[] args) {
		
		EdgeDriver ed= new EdgeDriver();
		ed.get("http://www.leaftaps.com/opentaps");
		ed.manage().window().maximize();
		ed.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		ed.findElement(By.xpath("//input[@id='username']")).sendKeys("demoSalesManager");
		ed.findElement(By.xpath("//input[@name='PASSWORD']")).sendKeys("crmsfa");
		ed.findElement(By.xpath("//input[@class='decorativeSubmit']")).click();
		ed.findElement(By.xpath("//a[contains(text(),'CRM/')]")).click();
		ed.findElement(By.xpath("//a[text()='Leads']")).click();
		
	}
}
