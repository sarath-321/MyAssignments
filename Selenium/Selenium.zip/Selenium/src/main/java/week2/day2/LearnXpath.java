package week2.day2;
//class room
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class LearnXpath {

	public static void main(String[] args) {
		
		ChromeDriver cd= new ChromeDriver();
		cd.get("http://leaftaps.com/opentaps/control/main");
		cd.manage().window().maximize();
		
		cd.findElement(By.xpath("//input[@id='username']")).sendKeys("demoSalesManager");
		cd.findElement(By.xpath("//input[@id='password']")).sendKeys("crmsfa");
		cd.findElement(By.xpath("//input[@class='decorativeSubmit']")).click();
		cd.findElement(By.xpath("//a[contains(text(),'CRM')]")).click();
		cd.findElement(By.xpath("//a[text()='Leads']")).click();

	}

}
