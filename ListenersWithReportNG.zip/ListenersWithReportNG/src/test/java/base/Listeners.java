package base;

import java.io.IOException;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.Reporter;

import util.testUtils;

public class Listeners extends testUtils implements ITestListener{

	public void onTestStart(ITestResult result) {
		
		Reporter.log("Method name is - "+result.getName());
		System.out.println("***Test started***");
	  }

	  
	  public void onTestSuccess(ITestResult result) {
		  Reporter.log("Status of execution is - "+result.getStatus());
	  }

	  
	  public void onTestFailure(ITestResult result) {
		  
		  try {
				getScreenshot();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  System.out.println("Test failed - screenshot captured");
		  System.setProperty("org.uncommons.reportng.escape-output","false");
		  Reporter.log("<a href=\"C:\\Sara\\Testing\\sampleWorkspace\\ListenersWithReportNG\\snaps\\img"+sss+".png\">Test Results</a>");
	  }

	  
	  public void onTestSkipped(ITestResult result) {
		  System.out.println("***Test skipped :"+result.getName());
	  }

	  
	  public void onTestFailedButWithinSuccessPercentage(ITestResult result) {

	  }

	  
	  public void onTestFailedWithTimeout(ITestResult result) {
	    
	  }

	  
	  public void onStart(ITestContext context) {

	  }

	  
	  public void onFinish(ITestContext context) {
		  //System.out.println("***Test completed :"+context.getName());
	  }
	
}
