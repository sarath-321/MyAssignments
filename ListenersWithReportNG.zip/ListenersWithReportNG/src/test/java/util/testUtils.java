package util;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;

import base.BaseClass;

public class testUtils extends BaseClass{

	public void getScreenshot() throws IOException {
		
		LocalDateTime myObj = LocalDateTime.now();
		DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
		String format = myObj.format(myFormatObj);
		System.out.println("Date and time format "+format);
		
		sss = format.toString().replace(" ","-").replace(":","-");
		
		File source = driver.getScreenshotAs(OutputType.FILE);
		File dest= new File("./snaps/img"+sss+".png");
		FileUtils.copyFile(source, dest);
		

	
	}
}
