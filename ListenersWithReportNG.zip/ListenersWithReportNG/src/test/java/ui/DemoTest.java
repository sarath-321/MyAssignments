package ui;

import org.testng.Assert;
import org.testng.annotations.Test;

import base.BaseClass;

public class DemoTest extends BaseClass {

	@Test
	public void test1() {
		System.out.println("This is Test1");
		driver.get("https://amazon.com");
		Assert.assertTrue(false);
	}
	
	
	
	
}
