package testcases01;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class Login extends ProjectSpecificMethod{

	@BeforeTest
	public void setData() {
		testcaseName="Login";
		testDesc="Positive Credentials";
		author="Sarath";
		category="Funtionality";
	}
	
	
	@Test
	public void runLogin() throws IOException {
			
		LoginPage ob=new LoginPage(driver,node);
		ob.enterUsername()
		.enterPassword()
		.clickLogin();
		
		
	}
	
}
