package pages;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.ExtentTest;

import base.ProjectSpecificMethod;
import io.github.sukgu.Shadow;

public class WelcomePage extends ProjectSpecificMethod{
	
	public WelcomePage(RemoteWebDriver driver,ExtentTest node) {
		this.driver = driver;
		this.node = node;
	}
	
	public WelcomePage clickAll() throws IOException {
		try {
		sh = new Shadow(driver);
		sh.setImplicitWait(50);
		sh.findElementByXPath("//div[text()='All']").click();
		reportStatus("pass", "All button is clicked successfully");
		}
		catch(Exception e) {
			reportStatus("fail", "All button is not clicked");
		}
		return this;
	}
	
	public WelcomePage enterTextInFilter() throws IOException {
		try {
			sh.setImplicitWait(30);
			sh.findElementByXPath("//input[@placeholder='Filter']").sendKeys("Incidents");
			reportStatus("pass", "Successfully entered text in filter");
		}
		catch(Exception e) {
			reportStatus("fail", "Text not entered in filter");
		}
		return this;
	}
	
	
	public IncidentViewPage clickHighlightedItem() throws IOException {
		try {
			sh.setImplicitWait(30);
			sh.findElementByXPath("//a[contains(@class,'nested-item item-label keyboard-navigatable highlighted-item')]")
					.click();
			reportStatus("pass", "Highlighted item is clicked successfully");
			Thread.sleep(6000);
			sh.setImplicitWait(30);
			WebElement frm = sh.findElementByXPath("//iframe[@id='gsft_main']");
			driver.switchTo().frame(frm);
			Thread.sleep(6000);
		}
		catch(Exception e) {
			reportStatus("fail", "Highlighted item is not clicked");
		}
		return new IncidentViewPage(driver,node);
	}
	
	
	

}
