package pages;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.ExtentTest;

import base.ProjectSpecificMethod;
import io.github.sukgu.Shadow;

public class createNewIncidentPage extends ProjectSpecificMethod{
	
	public createNewIncidentPage(RemoteWebDriver driver,ExtentTest node) {
		this.driver = driver;
		this.node = node;
	}
	
	public createNewIncidentPage enterDesc(String description) throws IOException {
		try {
			Shadow sh2= new Shadow(driver);
			sh2.setImplicitWait(30);
			WebElement name = sh2.findElementByXPath("//input[@id='incident.number']");
			incidentNumber = name.getAttribute("value");
			System.out.println("Incident number is :" + incidentNumber);
			sh2.setImplicitWait(30);
			sh2.findElementByXPath("//input[@id='incident.short_description']").sendKeys(description);
			reportStatus("pass", "Description entered successfully");
		}
		catch(Exception e) {
			reportStatus("fail", "Description is not entered");
		}
		return this;
	}
	
	public IncidentViewPage clickSubmit() throws IOException {
		try {
			Shadow sh3= new Shadow(driver);
			sh3.setImplicitWait(30);
			sh3.findElementByXPath("//button[@id='sysverb_insert_bottom']").click();
			reportStatus("pass", "Submit button is clicked successfully");
		}
		catch(Exception e) {
			reportStatus("fail", "Submit button is not clicked");
		}
		return new IncidentViewPage(driver,node);
	}

}
