package pages;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.ExtentTest;

import base.ProjectSpecificMethod;
import io.github.sukgu.Shadow;

public class IncidentViewPage extends ProjectSpecificMethod {

	public IncidentViewPage(RemoteWebDriver driver, ExtentTest node) {
		this.driver = driver;
		this.node = node;
	}

	public createNewIncidentPage clickNew() throws IOException {
		try {
			Shadow sh1= new Shadow(driver);
			sh1.setImplicitWait(30);
			sh1.findElementByXPath("//button[text()='New']").click();
			reportStatus("pass", "New is clicked successfully");
		} catch (Exception e) {
			reportStatus("fail", "New is not clicked");
		}
		return new createNewIncidentPage(driver, node);
	}


	public IncidentViewPage searchIncidentNumber() throws IOException {
		try {
			Shadow search= new Shadow(driver);
			search.setImplicitWait(30);
			search.findElementByXPath("//input[@placeholder='Search']").sendKeys(incidentNumber, Keys.ENTER);
			reportStatus("pass", "Incident number is entered successfully");
		} catch (Exception e) {
			reportStatus("fail", "Incident number is not entered");
		}
		return this;
	}

	public IncidentViewPage verifyIncident() {
		Shadow verify= new Shadow(driver);
		verify.setImplicitWait(30);
		list = verify.findElementsByXPath("//a[@class='linked formlink']");
		boolean bl = false;
		for (WebElement webElement : list) {
			if (webElement.getText().contains(incidentNumber)) {
				bl = true;
				break;
			}
		}
		if (bl) {
			System.out.println("New incident created successfully!");
		} else {
			System.out.println("New incident not created!");
		}
		return this;
	}
	
	public IncidentPage clickIncident() throws IOException {
		try {
			Shadow clickInc= new Shadow(driver);
			clickInc.setImplicitWait(30);
			clickInc.findElementByXPath("//a[contains(@class,'linked formlink')]").click();
			reportStatus("pass", "Incident clicked successfully");
		}
		catch(Exception e) {
			reportStatus("fail", "Incident not clicked");
		}
		return new IncidentPage(driver,node);
	}
	
	public IncidentViewPage enterIncidentNumber(String incNumber) throws IOException {
		try {
			Shadow enterInc=new Shadow(driver);
			enterInc.setImplicitWait(30);
			enterInc.findElementByXPath("//input[@placeholder='Search']").sendKeys(incNumber,Keys.ENTER);
			reportStatus("pass", "Incident number is entered successfully");
		} catch (Exception e) {
			reportStatus("fail", "Incident number is not entered");
		}
		return this;
	}
	
	public IncidentPage verifyUpdatedIncident() throws IOException {
		try {
			Shadow verifyUpInc= new Shadow(driver);
			verifyUpInc.setImplicitWait(30);
			verifyUpInc.findElementByXPath("//a[contains(@class,'linked formlink')]").click();
			Thread.sleep(2000);
			System.out.println("Incident updated successfully!");
			reportStatus("pass", "Incident updated successfully");
		}
		catch(Exception e) {
			reportStatus("fail", "Incident not updated");
		}
		return new IncidentPage(driver,node);
	}
	
	
	public IncidentViewPage verifyDeletedIncident(String incNumber) throws IOException {
		try {
			Shadow verifyDel= new Shadow(driver);
			verifyDel.setImplicitWait(30);
			List<WebElement> list = verifyDel.findElementsByXPath("//a[@class='linked formlink']");
			boolean flag = false;
			for (WebElement webElement : list) {
				if (webElement.getText().contains(incNumber)) {
					flag = true;
					break;
				}
			}
			if (flag) {
				System.out.println("Incident not deleted!");
			} else {
				System.out.println("Incident deleted successfully!");
			}
			reportStatus("pass", "Deleted incident verified successfully");
		}
		catch(Exception e) {
			reportStatus("fail", "Deleted incident not verified");
		}
		return this;
	}
	
}
