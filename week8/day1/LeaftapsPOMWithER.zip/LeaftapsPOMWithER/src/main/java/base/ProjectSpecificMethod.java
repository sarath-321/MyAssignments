package base;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import util.ReadExcelData;


public class ProjectSpecificMethod {

	
	public RemoteWebDriver driver;
	public static String text;
	public String fileName;
	public static String leadID;
	public List<String> allhandles;
	public  static ExtentReports extent;
	public  static ExtentTest test,node;
	public String testcaseName, testDesc, author, category;
	
	
	
	@Parameters({"browser"})
	@BeforeMethod
	public void preCOndition(String browser) {
		node = test.createNode(testcaseName);
		if(browser.equalsIgnoreCase("chrome")) {
			driver = new ChromeDriver();
		}
		else if(browser.equalsIgnoreCase("edge")) {
			driver =new EdgeDriver();
		}
		System.out.println(driver);
		driver.manage().window().maximize();
		driver.get("http://leaftaps.com/opentaps/control/main");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
	}
	
	@AfterMethod
	public void postCondition() {
		driver.close();
	}		
	
	@DataProvider(name="fetchData")
	public String[][] sendData() throws IOException {	
		return ReadExcelData.readExcel(fileName);
			
	} 
	
	@BeforeSuite
	public void startReport() {
		ExtentHtmlReporter reporter = new ExtentHtmlReporter("./reports/result.html");
		extent = new ExtentReports();
		reporter.setAppendExisting(true);
		extent.attachReporter(reporter);
	}

	@BeforeClass
	public void testDetails() {
		test = extent.createTest(testcaseName, testDesc);
		test.assignCategory(category);
		test.assignAuthor(author);
	}

	public void reportStatus(String status, String info) throws IOException {
		if (status.equalsIgnoreCase("pass")) {
			node.pass(info, MediaEntityBuilder.createScreenCaptureFromPath(".././snap/shot"+takeSnap()+".png").build());

		} else if (status.equalsIgnoreCase("fail")) {
			node.fail(info, MediaEntityBuilder.createScreenCaptureFromPath(".././snap/shot"+takeSnap()+".png").build());
			throw new RuntimeException("Check the testStep");
		}
	}	
	
	public int takeSnap() throws IOException {	
		int random =(int)(Math.random()*999999);
		File source = driver.getScreenshotAs(OutputType.FILE);
	    File destn=new File("./snap/shot"+random+".png");
	  FileUtils.copyFile(source, destn);
	  return random;
	}
	
	

	@AfterSuite
	public void endReport() {
		extent.flush();
	}
	
	
	
}
