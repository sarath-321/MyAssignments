package pages;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.ExtentTest;

import base.ProjectSpecificMethod;

public class NewFindLeadsWindowPage extends ProjectSpecificMethod {

	public NewFindLeadsWindowPage(RemoteWebDriver driver, ExtentTest node) {
		this.driver = driver;
		this.node = node;
	}

	public NewFindLeadsWindowPage switchFirstWindow() throws IOException {
		try {
			Set<String> allWindows = driver.getWindowHandles();
			allhandles = new ArrayList<String>(allWindows);
			driver.switchTo().window(allhandles.get(1));
			reportStatus("pass", "Window switched successfully");
		} catch (Exception e) {
			reportStatus("fail", "Window not switched");
		}
		return this;
	}

	public NewFindLeadsWindowPage enterFirstName(String firstName) throws IOException {
		try {
			driver.findElement(By.xpath("//input[@name='firstName']")).sendKeys(firstName);
			reportStatus("pass", "FirstName entered successfully");
		} catch (Exception e) {
			reportStatus("fail", "FirstName not entered");
		}
		return this;
	}

	public NewFindLeadsWindowPage clickFindLeads() throws InterruptedException, IOException {
		try {
			driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
			Thread.sleep(1000);
			reportStatus("pass", "FindLeads clicked successfully");
		} catch (Exception e) {
			reportStatus("fail", "FindLeads not clicked");
		}
		return this;
	}

	public NewFindLeadsWindowPage getLeadId() {

		leadID = driver.findElement(By.xpath("(//a[@class='linktext'])[1]")).getText();
		System.out.println("Lead id :" + leadID);
		return this;
	}

	public MergeLeadPage clickFirstElement1() throws IOException {
		try {
			driver.findElement(By.xpath("(//a[@class='linktext'])[1]")).click();
			reportStatus("pass", "FirstElement1 clicked successfully");
		} catch (Exception e) {
			reportStatus("fail", "FirstElement1 not clicked");
		}
		return new MergeLeadPage(driver, node);
	}

	public NewFindLeadsWindowPage enterMergeFirstName(String mergeFirstName) throws IOException {
		try {
			driver.findElement(By.xpath("//input[@name='firstName']")).sendKeys(mergeFirstName);
			reportStatus("pass", "MergeFirstName entered successfully");
		} catch (Exception e) {
			reportStatus("fail", "MergeFirstName not entered");
		}
		return this;
	}

	public MergeLeadPage clickFirstElement2() throws IOException {
		try {
			driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).click();
			reportStatus("pass", "FirstElement2 clicked successfully");
		} catch (Exception e) {
			reportStatus("fail", "FirstElement2 not clicked");
		}
		return new MergeLeadPage(driver, node);
	}

}
