package pages;

import java.io.IOException;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.ExtentTest;

import base.ProjectSpecificMethod;

public class AlertPage extends ProjectSpecificMethod{
	
	public AlertPage(RemoteWebDriver driver,ExtentTest node) {
		this.driver=driver;
		this.node=node;
	}
	
	public ViewLeadPage acceptAlert() throws IOException {
		try {
		driver.switchTo().alert().accept();
		reportStatus("pass","Alert accepted successfully");
		}
		catch(Exception e) {
			 reportStatus("fail", "Alert not accepted");
		}
		return new ViewLeadPage(driver,node);
		
	}

}
