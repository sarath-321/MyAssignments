package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.ExtentTest;

import base.ProjectSpecificMethod;

public class DuplicateLeadPage extends ProjectSpecificMethod{
	
	public DuplicateLeadPage(RemoteWebDriver driver,ExtentTest node) {
		this.driver=driver;
		this.node=node;
	}
	
	public DuplicateLeadPage clearCompName() throws IOException {
		try {
		driver.findElement(By.id("createLeadForm_companyName")).clear();
		reportStatus("pass","CompanyName cleared successfully");
		}
		catch(Exception e) {
			reportStatus("fail", "CompanyName not cleared");
		}
		return this;
	}
	public DuplicateLeadPage enterDupCompName(String dupCompanyName) throws IOException {
		try {
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(dupCompanyName);
		reportStatus("pass","DupCompanyName entered successfully");
		}
		catch(Exception e) {
			reportStatus("fail", "DupCompanyName not entered");	
		}
		return this;
	}
	
	public DuplicateLeadPage clearfirstNameLocal() throws IOException {
		try {
		driver.findElement(By.id("createLeadForm_firstNameLocal")).clear();
		reportStatus("pass","FirstNameLocal cleared successfully");
		}
		catch(Exception e) {
			reportStatus("fail", "FirstNameLocal not cleared");
		}
		
		return this;
	}
	public DuplicateLeadPage enterDupFirstNameLocal(String dupFirstNameLocal) throws IOException {
		try {
		driver.findElement(By.id("createLeadForm_firstNameLocal")).sendKeys(dupFirstNameLocal);
		reportStatus("pass","DupFirstNameLocal entered successfully");
		}
		catch(Exception e) {
			reportStatus("fail", "DupFirstNameLocal not entered");	
		}
		return this;
	}
	
	public ViewLeadPage clickSubmit() throws IOException {
		try {
		driver.findElement(By.className("smallSubmit")).click();
		reportStatus("pass","Submit button clicked successfully");
		}
		catch(Exception e) {
			reportStatus("fail", "Submit button not clicked");	
		}
		return new ViewLeadPage(driver,node);
	}
	

}
