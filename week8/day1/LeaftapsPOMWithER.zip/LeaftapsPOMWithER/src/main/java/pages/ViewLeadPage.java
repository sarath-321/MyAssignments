package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.ExtentTest;

import base.ProjectSpecificMethod;


public class ViewLeadPage extends ProjectSpecificMethod{

	public ViewLeadPage(RemoteWebDriver driver,ExtentTest node) {
		this.driver=driver;
		this.node=node;
	}
	
	public ViewLeadPage checkViewLeadPage(String cname) {
		
		text = driver.findElement(By.id("viewLead_companyName_sp")).getText();
		   if (text.contains(cname)) {
				System.out.println("Lead created successfully");
			} else {
				System.out.println("Lead is not created");
			}
		   return this;
	}
	
	public EditLeadPage clickEdit() throws IOException {
		try {
		driver.findElement(By.linkText("Edit")).click();
		reportStatus("pass","Edit clicked successfully");
		}
		catch(Exception e) {
			reportStatus("fail", "Edit not clicked");
		}
		return new EditLeadPage(driver,node);
	}
	
	public void verifyCompanyName(String compName) throws InterruptedException {
		String text = driver.findElement(By.id("viewLead_companyName_sp")).getText();
		if (text.contains(compName)) {
			System.out.println("Lead is editted successfully");
		}
		else {
			System.out.println("Lead is not editted");
		}
		Thread.sleep(3000);
	}
	
	
	public DuplicateLeadPage clickDuplicateLead() throws IOException {
		try {
		driver.findElement(By.linkText("Duplicate Lead")).click();
		reportStatus("pass","Duplicate Lead clicked successfully");
		}
		catch(Exception e) {
			reportStatus("fail", "Duplicate Lead not clicked");
		}
		return new DuplicateLeadPage(driver,node);
	}
	
	
	public void verifyDupCompanyName(String dupCompanyName) throws InterruptedException {
		String text = driver.findElement(By.id("viewLead_companyName_sp")).getText();
		if (text.contains(dupCompanyName)) {
			System.out.println("Duplicate Lead is created successfully");
		}
		else {
			System.out.println("Duplicate Lead is not created");
		}
		Thread.sleep(3000);
	}
	
	public FindLeadsPage clickFindLeads() throws IOException {
		try {
		driver.findElement(By.linkText("Find Leads")).click();
		reportStatus("pass","Find Leads clicked successfully");
		}
		catch(Exception e) {
			reportStatus("fail", "Find Leads not clicked");	
		}
		return new FindLeadsPage(driver,node);
	}
	
	public MyLeadsPage clickDelete() throws IOException {
		try {
		driver.findElement(By.linkText("Delete")).click();
		reportStatus("pass","Delete clicked successfully");
		}
		catch(Exception e) {
			reportStatus("fail", "Delete is not clicked");	
		}
		return new MyLeadsPage(driver,node);
	}
	
}
