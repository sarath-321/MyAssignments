package testcasess;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;


public class CreateLead extends ProjectSpecificMethod {

	@BeforeTest
	public void setFile() {
		fileName="DuplicateLeadData";
		testcaseName="CreateLead";
		testDesc="Creating Leads";
		author="Sarath";
		category="Regression";
	}
	
	@Test(dataProvider = "fetchData")
	public void runCreate(String cname,
			String fname,String lname,String phnNo,String firstNameLocal
           ,String departmentName,String description,String email
           ,String dupCompanyName,String dupFirstNameLocal) throws IOException {
		
		LoginPage ob=new LoginPage(driver,node);
		ob.enterUsername()
		.enterPassword()
		.clickLogin()
		.clickCrmsfa()
		.clickLeads()
		.clickCreateLead()
		.enterCompanyname(cname)
		.enterFirstName(fname)
		.enterLastName(lname)
		.enterprimaryPhoneNumber(phnNo)
		.clickSubmit()
		.checkViewLeadPage(cname);
		
		
	}
	
}
