package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;
import pages.WelcomePage;

public class Login extends ProjectSpecificMethod {

	@BeforeTest
	public void setData() {
		testcaseName="Login";
		testDesc="Positive Credentials";
		author="Suneetha";
		category="Funtionality";
	}
	
	
	@Test
	public void runLogin() throws IOException {
		
		LoginPage ob=new LoginPage(driver,node);
		ob.enterUsername()
		.enterPassword()
		.clickLogin()
		.clickCrmsfa()
		.verifyHomePage();
		
		
	}
	
}
