package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.ExtentTest;

import base.ProjectSpecificMethod;

public class CreateLeadPage extends ProjectSpecificMethod{

	public CreateLeadPage (RemoteWebDriver driver,ExtentTest node) {
		this.driver=driver;
		this.node=node;		
	}	
	public CreateLeadPage enterCompanyname(String cname) throws IOException {
		try{
			driver.findElement(By.id("createLeadForm_companyName")).sendKeys(cname);
		reportStatus("pass","CompanyName is entered successfully");
		}
	catch(Exception e) {
		reportStatus("fail", "CompanyName is not entered successfully");
	}
	
	return this;
		
	}
	
	public CreateLeadPage enterFirstName(String fname) throws IOException {
		try{
			driver.findElement(By.id("createLeadForm_firstName")).sendKeys(fname);
		reportStatus("pass","Firstname is entered successfully");
	}
	catch(Exception e) {
		reportStatus("fail", "Firstname is not entered successfully");
	}
	
		return this;
				
	}	
	
	public CreateLeadPage enterLastName(String lname) throws IOException {
		try{
			driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lname);
			reportStatus("pass","lastName is entered successfully");
		}
		catch(Exception e) {
			reportStatus("fail", "lastName is not entered successfully");
		}	
	return this;
	}
	
	public ViewLeadPage clickCreate() {
		driver.findElement(By.name("submitButton")).click();
		return new ViewLeadPage(driver);
	}
	
	
}




