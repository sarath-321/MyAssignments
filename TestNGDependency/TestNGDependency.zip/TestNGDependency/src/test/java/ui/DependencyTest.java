package ui;

import org.testng.Assert;
import org.testng.annotations.Test;

public class DependencyTest {

	@Test
	public void userRegister() {
		System.out.println("User Registered successfully!");
	}
	
	@Test(dependsOnMethods = "userRegister")
	public void userLogin() {
		Assert.assertTrue(false);
		System.out.println("User Loggedin successfully!");
	}
	
	@Test(dependsOnMethods = "userLogin", alwaysRun = true)
	public void userSearch() {
		System.out.println("Searching user");
	}
	
	
	
}
