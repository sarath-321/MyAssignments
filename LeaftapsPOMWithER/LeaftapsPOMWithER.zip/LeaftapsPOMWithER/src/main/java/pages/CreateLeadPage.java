package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.ExtentTest;

import base.ProjectSpecificMethod;

public class CreateLeadPage extends ProjectSpecificMethod{

	public CreateLeadPage(RemoteWebDriver driver,ExtentTest node) {
		this.driver=driver;
		this.node=node;
	}
	
	public CreateLeadPage enterCompanyname(String cname) throws IOException {
		try {
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(cname);
		reportStatus("pass","CompanyName is entered successfully");
	}
       catch(Exception e) {
	   reportStatus("fail", "CompanyName is not entered successfully");
   }

return this;
	}
	
	public CreateLeadPage enterFirstName(String fname) throws IOException {
		try {
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(fname);
		reportStatus("pass","FirstName is entered successfully");
		}
		catch(Exception e) {
			reportStatus("fail", "FirstName is not entered successfully");
		}
		return this;
	}
	
   public CreateLeadPage enterLastName(String lname) throws IOException {
	   try {
	   driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lname);
	   reportStatus("pass","LastName is entered successfully");
	   }
	   catch(Exception e) {
		   reportStatus("fail", "LastName is not entered successfully");
	   }
	   return this;
	}
   
   public CreateLeadPage enterprimaryPhoneNumber(String phnNo) throws IOException {
	   try {
	   driver.findElement(By.id("createLeadForm_primaryPhoneNumber")).sendKeys(phnNo);
	   reportStatus("pass","PrimaryPhoneNumber is entered successfully");
	   }
	   catch(Exception e) {
		   reportStatus("fail", "PrimaryPhoneNumber is not entered successfully");
	   }
	   return this;
	}
   
   public CreateLeadPage enterFirstNameLocal(String firstNameLocal) throws IOException {
	   try {
	   driver.findElement(By.id("createLeadForm_firstNameLocal")).sendKeys(firstNameLocal);
	   reportStatus("pass","FirstNameLocal is entered successfully");
	   }
	   catch(Exception e) {
		   reportStatus("fail", "FirstNameLocal is not entered successfully");
	   }
	   return this;
	}
   
   public CreateLeadPage enterDepartmentName(String departmentName) throws IOException {
	   try {
	   driver.findElement(By.id("createLeadForm_departmentName")).sendKeys(departmentName);
	   reportStatus("pass","DepartmentName is entered successfully");
	   }
	   catch(Exception e) {
		   reportStatus("fail", "DepartmentName is not entered successfully");
	   }
	   return this;
	}
   
   public CreateLeadPage enterDescription(String description) throws IOException {
	   try {
	   driver.findElement(By.id("createLeadForm_description")).sendKeys(description);
	   reportStatus("pass","Description is entered successfully");
	   }
	   catch(Exception e) {
		   reportStatus("fail", "Description is not entered successfully");
	   }
	   return this;
	}
   
   public CreateLeadPage enterEmail(String email) throws IOException {
	   try {
	   driver.findElement(By.id("createLeadForm_primaryEmail")).sendKeys(email);
	   reportStatus("pass","PrimaryEmail is entered successfully");
	   }
	   catch(Exception e) {
		   reportStatus("fail", "PrimaryEmail is not entered successfully");
	   }
	   return this;
	}
   public CreateLeadPage selectState() throws IOException {
	   try {
	   WebElement state = driver.findElement(By.id("createLeadForm_generalStateProvinceGeoId"));
		Select select= new Select(state);
		select.selectByVisibleText("Alaska");
		 reportStatus("pass","State selected successfully");
	   }
	   catch(Exception e) {
		   reportStatus("fail", "State not selected"); 
	   }
	   return this;
	}
     
   public ViewLeadPage clickSubmit() throws IOException {
	   try {
	   driver.findElement(By.name("submitButton")).click();
	   reportStatus("pass","Submit button clicked successfully");
	   }
	   catch(Exception e) {
		   reportStatus("fail", "Submit button not clicked");   
	   }
	   return new ViewLeadPage(driver,node);
	}
	
	
	
}
