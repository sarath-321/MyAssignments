package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.ExtentTest;

import base.ProjectSpecificMethod;

public class MyHomePage extends ProjectSpecificMethod{
	
	public MyHomePage(RemoteWebDriver driver,ExtentTest node) {
		this.driver=driver;
		this.node=node;
	}
	
	public MyHomePage verifyHomePage() {		
		System.out.println(driver.getTitle());
		return this;
		
	}	
	
	public LeadsPage clickLeads() throws IOException {
		try {
		driver.findElement(By.linkText("Leads")).click();
		reportStatus("pass","Lead clicked successfully");
		}
		catch(Exception e) {
			reportStatus("fail", "Lead not clicked");
		}
		return new LeadsPage(driver,node);
	}
	
	
}
