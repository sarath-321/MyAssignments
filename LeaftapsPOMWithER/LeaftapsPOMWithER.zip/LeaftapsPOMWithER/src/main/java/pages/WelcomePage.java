package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.ExtentTest;

import base.ProjectSpecificMethod;

public class WelcomePage extends ProjectSpecificMethod{

	
	public WelcomePage(RemoteWebDriver driver,ExtentTest node) {
		this.driver=driver;
		this.node=node;
	}
	
	public MyHomePage clickCrmsfa() throws IOException {
		try {
		driver.findElement(By.linkText("CRM/SFA")).click();
		reportStatus("pass","CRMSFA clicked successfully");
		}
		catch(Exception e) {
			reportStatus("fail", "CRMSFA is not clicked");
		}
		return new MyHomePage(driver,node);
	}
	
	public void clickLogout() {
		
	}
	
	
}
