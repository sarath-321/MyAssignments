package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.ExtentTest;

import base.ProjectSpecificMethod;

public class EditLeadPage extends ProjectSpecificMethod{
	
	public EditLeadPage(RemoteWebDriver driver,ExtentTest node) {
		this.driver=driver;
		this.node=node;
	}
	
	public EditLeadPage editCompanyName(String compName) throws IOException {
		try {
		WebElement companyName = driver.findElement(By.id("updateLeadForm_companyName"));
		companyName.clear();
		reportStatus("pass","Edit CompanyName cleared successfully");
		companyName.sendKeys(compName);
		reportStatus("pass","Edit CompanyName entered successfully");
		}
		catch(Exception e) {
			reportStatus("fail", "Edit CompanyName is not cleared/entered");
		}
		return this;
	}
	
	public ViewLeadPage clickUpdate() throws IOException {
		try {
		driver.findElement(By.name("submitButton")).click();
		reportStatus("pass","Submit button clicked successfully");
		}
		catch(Exception e) {
			reportStatus("fail", "Submit button is not clicked");	
		}
		return new ViewLeadPage(driver,node);
	}

}
