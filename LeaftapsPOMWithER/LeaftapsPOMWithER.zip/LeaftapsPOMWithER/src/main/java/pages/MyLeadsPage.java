package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.ExtentTest;

import base.ProjectSpecificMethod;

public class MyLeadsPage extends ProjectSpecificMethod{
	
	public MyLeadsPage(RemoteWebDriver driver,ExtentTest node) {
		this.driver=driver;
		this.node=node;
	}
	
	public FindLeadsPage clickFindLeads() throws IOException {
		try {
		driver.findElement(By.linkText("Find Leads")).click();
		reportStatus("pass","FindLeads clicked successfully");
		}
		catch(Exception e) {
			reportStatus("fail", "FindLeads not clicked");
		}
		return new FindLeadsPage(driver,node);
	}

}
