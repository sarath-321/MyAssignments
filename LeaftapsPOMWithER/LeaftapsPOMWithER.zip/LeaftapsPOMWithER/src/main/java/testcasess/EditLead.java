package testcasess;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class EditLead extends ProjectSpecificMethod{

	@BeforeTest
	public void setFile() {
		fileName="EditLeadData";
		testcaseName="EditLead";
		testDesc="Editing Lead";
		author="Sarath";
		category="Regression";
	}
	
	@Test(dataProvider = "fetchData")
	public void runEditLead(String phoneNumber,String compName) throws InterruptedException, IOException {
		
		LoginPage ob=new LoginPage(driver,node);
		ob.enterUsername()
		.enterPassword()
		.clickLogin()
		.clickCrmsfa()
		.clickLeads()
		.clickFindLeads()
		.clickPhone()
		.enterPhoneNumber(phoneNumber)
		.clickFindLeads()
		.clickFirstElement()
		.clickEdit()
		.editCompanyName(compName)
		.clickUpdate()
		.verifyCompanyName(compName);
		
		
		
	}
	
}

