package testcasess;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class MergeLead extends ProjectSpecificMethod{

	@BeforeTest
	public void setFile() {
		fileName="MergeLeadData";
		testcaseName="MergeLead";
		testDesc="Merging Lead";
		author="Sarath";
		category="Regression";
	}
	
	@Test(dataProvider = "fetchData")
	public void runEditLead(String firstName,String mergeFirstName) throws InterruptedException, IOException {
		
		LoginPage ob=new LoginPage(driver,node);
		ob.enterUsername()
		.enterPassword()
		.clickLogin()
		.clickCrmsfa()
		.clickLeads()
		.clickMergeLead()
		.clickLookupOne()
		.switchFirstWindow()
		.enterFirstName(firstName)
		.clickFindLeads()
		.getLeadId()
		.clickFirstElement1()
		.switchDriver1()
		.clickLookupTwo()
		.switchFirstWindow()
		.enterMergeFirstName(mergeFirstName)
		.clickFindLeads()
		.clickFirstElement2()
		.switchDriver1()
		.clickMerge()
		.acceptAlert()
		.clickFindLeads()
		.enterLeadId()
		.clickFindLeads()
		.verifyMatching()
		;
		
		
		
	}
}
