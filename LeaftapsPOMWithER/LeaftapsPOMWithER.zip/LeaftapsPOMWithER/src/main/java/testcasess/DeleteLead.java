package testcasess;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class DeleteLead extends ProjectSpecificMethod{

	@BeforeTest
	public void setFile() {
		fileName="DeleteLeadData";
		testcaseName="DeleteLead";
		testDesc="Deleting Lead";
		author="Sarath";
		category="Regression";
	}
	
	@Test(dataProvider = "fetchData")
	public void runEditLead(String phoneNumber) throws InterruptedException, IOException {
		
		LoginPage ob=new LoginPage(driver,node);
		ob.enterUsername()
		.enterPassword()
		.clickLogin()
		.clickCrmsfa()
		.clickLeads()
		.clickFindLeads()
		.clickPhone()
		.enterPhoneNumber(phoneNumber)
		.clickFindLeads()
		.clickFirstElement()
		.clickDelete()
		.clickFindLeads()
		.clickPhone()
		.enterPhoneNumber(phoneNumber)
		.clickFindLeads()
		.verifyDeleteLead()
		;
		
		
		
	}
}
