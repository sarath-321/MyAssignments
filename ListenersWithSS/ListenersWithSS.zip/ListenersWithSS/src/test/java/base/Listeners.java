package base;

import java.io.IOException;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import util.testUtils;

public class Listeners extends testUtils implements ITestListener{
	
	public void onTestStart(ITestResult result) {
		System.out.println("***Test started :"+result.getName());
	  }

	  
	  public void onTestSuccess(ITestResult result) {
		  System.out.println("***Test success :"+result.getName());
	  }

	  
	  public void onTestFailure(ITestResult result) {
		  System.out.println("***Test failed :"+result.getName());
		  try {
			getScreenshot();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	  }

	  
	  public void onTestSkipped(ITestResult result) {
		 // System.out.println("***Test skipped :"+result.getName());
	  }

	  
	  public void onTestFailedButWithinSuccessPercentage(ITestResult result) {

	  }

	  
	  public void onTestFailedWithTimeout(ITestResult result) {
	    
	  }

	  
	  public void onStart(ITestContext context) {

	  }

	  
	  public void onFinish(ITestContext context) {
		  //System.out.println("***Test completed :"+context.getName());
	  }

}
