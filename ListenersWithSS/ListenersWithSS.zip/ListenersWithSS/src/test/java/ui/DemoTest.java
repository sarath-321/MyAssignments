package ui;

import org.testng.Assert;
import org.testng.annotations.Test;

import base.BaseClass;

public class DemoTest extends BaseClass{

	@Test
	public void launchApp() throws InterruptedException {
		
		driver.get("https://ebay.com");
		Thread.sleep(3000);
		Assert.assertTrue(false);
	}
}
