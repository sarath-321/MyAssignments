package pages;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.ExtentTest;

import base.ProjectSpecificMethod;

public class MergeLeadPage extends ProjectSpecificMethod{

	
	public MergeLeadPage(RemoteWebDriver driver,ExtentTest node) {
		this.driver = driver;
		this.node = node;

	}
	
	public NewFindLeadsWindowPage clickLookupOne() throws IOException {
		try {
		driver.findElement(By.xpath("//img[@alt='Lookup']")).click();
		reportStatus("pass","LooupOne clicked successfully");
		}
		catch(Exception e) {
			reportStatus("fail", "LooupOne not clicked ");
		}
		return new NewFindLeadsWindowPage(driver,node);
	}
	
	public MergeLeadPage switchDriver1() throws IOException {
		try {
		Set<String> allWindowss = driver.getWindowHandles();
		allhandles = new ArrayList<String>(allWindowss);
		driver.switchTo().window(allhandles.get(0));
		reportStatus("pass","Window switched successfully");
		}
		catch(Exception e) {
			reportStatus("fail", "Window not switched");
		}
		return this;
	}
	
	public NewFindLeadsWindowPage clickLookupTwo() throws IOException {
		try {
		driver.findElement(By.xpath("(//img[@alt='Lookup'])[2]")).click();
		Set<String> allWindows = driver.getWindowHandles();
		allhandles = new ArrayList<String>(allWindows);
		reportStatus("pass","LooupTwo clicked successfully");
		}
		catch(Exception e) {
			reportStatus("fail", "LooupTwo not clicked ");
		}
		return new NewFindLeadsWindowPage(driver,node);
		
	}
	
	public MergeLeadPage switchDriver2() throws IOException {
		try {
		driver.switchTo().window(allhandles.get(0));
		reportStatus("pass","Window switched successfully");
		}
		catch(Exception e) {
			reportStatus("fail", "Window not switched");
		}
		return this;
	}
	
	public AlertPage clickMerge() throws IOException {
		try {
		driver.findElement(By.xpath("//a[text()='Merge']")).click();
		reportStatus("pass","Merge clicked successfully");
		}
		catch(Exception e) {
			reportStatus("fail", "Merge not clicked ");
		}
		return new AlertPage(driver,node);
	}
	
}
