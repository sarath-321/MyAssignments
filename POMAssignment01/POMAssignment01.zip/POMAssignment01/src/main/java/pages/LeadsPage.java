package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.ExtentTest;

import base.ProjectSpecificMethod;

public class LeadsPage extends ProjectSpecificMethod {
	
	
	public LeadsPage(RemoteWebDriver driver,ExtentTest node) {
		this.driver=driver;
		this.node =node;
	}
	
	public CreateLeadPage clickCreateLead() throws IOException {
		try {
		driver.findElement(By.linkText("Create Lead")).click();
		reportStatus("pass","CreateLead clicked successfully");
		}
		catch(Exception e) {
			reportStatus("fail", "CreateLead not clicked ");
		}
		return new CreateLeadPage(driver,node);
	}
	
	public FindLeadsPage clickFindLeads() throws IOException {
		try {
		driver.findElement(By.linkText("Find Leads")).click();
		reportStatus("pass","FindLeads clicked successfully");
		}
		catch(Exception e) {
			reportStatus("fail", "FindLeads not clicked ");
		}
		return new FindLeadsPage(driver,node);
	}
	
	
	public MergeLeadPage clickMergeLead() throws IOException {
		try {
		driver.findElement(By.linkText("Merge Leads")).click();
		reportStatus("pass","MergeLeads clicked successfully");
		}
		catch(Exception e) {
			reportStatus("fail", "MergeLeads not clicked ");
		}
		return new MergeLeadPage(driver,node);
	}

}
